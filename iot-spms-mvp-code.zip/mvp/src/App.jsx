import { useMemo, useState } from "react";

import usersData from "./data/mockUsers.json";
import zonesData from "./data/mockParkingZones.json";
import sessionsData from "./data/mockSessions.json";
import ticketsData from "./data/mockTickets.json";
import paymentsData from "./data/mockPayments.json";
import logsData from "./data/mockLogs.json";

import Layout from "./components/Layout.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import UserDashboard from "./pages/UserDashboard.jsx";
import ParkingAvailabilityMap from "./pages/ParkingAvailabilityMap.jsx";
import EntryExitPage from "./pages/EntryExitPage.jsx";
import TemporaryAccessPage from "./pages/TemporaryAccessPage.jsx";
import OperatorDashboard from "./pages/OperatorDashboard.jsx";
import SensorSimulationPage from "./pages/SensorSimulationPage.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import PricingPolicyPage from "./pages/PricingPolicyPage.jsx";
import AuditLogReportPage from "./pages/AuditLogReportPage.jsx";

import { addLog } from "./services/auditLogService.js";
import { canAccessParking } from "./services/mockDataCoreService.js";
import { buildDeviceAlert, getAvailableSlots, toggleGateway, updateZoneOccupancy } from "./services/mockIoTService.js";
import { createMemberSession, createTemporarySession, createTemporaryTicket, hasActiveSession, closeSession } from "./services/parkingSessionService.js";
import { calculateFee } from "./services/billingService.js";
import { createPaymentRequest, updatePaymentStatus } from "./services/mockBKPayService.js";

const initialPolicies = [
  {
    id: "POL-MEMBER-DEFAULT",
    name: "Default University Member Policy",
    userType: "member",
    baseFee: 3000,
    hourlyRate: 2000,
    active: true,
  },
  {
    id: "POL-TEMP-DEFAULT",
    name: "Default Temporary Visitor Policy",
    userType: "temporary",
    baseFee: 5000,
    hourlyRate: 3000,
    active: true,
  },
];

function chooseInitialPage(user) {
  if (user.role === "operator") return "operator-dashboard";
  if (user.role === "admin") return "admin-dashboard";
  return "user-dashboard";
}

function findBestZone(zones) {
  return zones
    .filter((zone) => zone.gatewayStatus === "online" && getAvailableSlots(zone) > 0)
    .sort((a, b) => getAvailableSlots(b) - getAvailableSlots(a))[0];
}

export default function App() {
  const [users] = useState(usersData);
  const [zones, setZones] = useState(zonesData);
  const [sessions, setSessions] = useState(sessionsData);
  const [tickets, setTickets] = useState(ticketsData);
  const [payments, setPayments] = useState(paymentsData);
  const [logs, setLogs] = useState(logsData);
  const [policies, setPolicies] = useState(initialPolicies);
  const [alerts, setAlerts] = useState([]);

  const [currentUser, setCurrentUser] = useState(null);
  const [activePage, setActivePage] = useState("login");

  const selectedActiveSession = useMemo(() => {
    if (!currentUser) return null;
    return sessions.find((session) => session.userId === currentUser.id && session.status === "Active");
  }, [currentUser, sessions]);

  const appendLog = (payload) => {
    setLogs((prev) => addLog(prev, payload));
  };

  const handleLogin = (user) => {
    setCurrentUser(user);
    setActivePage(chooseInitialPage(user));
    appendLog({
      actor: user.name,
      type: "Authentication",
      target: user.id,
      message: `Logged in as ${user.role}.`,
      result: "Success",
    });
  };

  const handleLogout = () => {
    if (currentUser) {
      appendLog({
        actor: currentUser.name,
        type: "Authentication",
        target: currentUser.id,
        message: "Logged out.",
        result: "Success",
      });
    }
    setCurrentUser(null);
    setActivePage("login");
  };

  const handleMemberEntry = (zoneId) => {
    if (!currentUser) return;

    if (!canAccessParking(currentUser)) {
      appendLog({
        actor: currentUser.name,
        type: "Entry",
        target: currentUser.id,
        message: "Entry denied because current role has no parking privilege.",
        result: "Denied",
      });
      alert("Entry denied: this role has no parking privilege.");
      return;
    }

    if (hasActiveSession(sessions, currentUser.id)) {
      appendLog({
        actor: currentUser.name,
        type: "Entry",
        target: currentUser.id,
        message: "Entry denied because the user already has an active session.",
        result: "Denied",
      });
      alert("You already have an active session.");
      return;
    }

    const selectedZone = zones.find((zone) => zone.id === zoneId);
    if (!selectedZone || selectedZone.gatewayStatus !== "online" || getAvailableSlots(selectedZone) <= 0) {
      appendLog({
        actor: currentUser.name,
        type: "Entry",
        target: zoneId,
        message: "Entry denied because selected zone is unavailable.",
        result: "Denied",
      });
      alert("Selected zone is unavailable. Please choose another zone.");
      return;
    }

    const session = createMemberSession({ user: currentUser, zoneId });
    setSessions((prev) => [session, ...prev]);
    setZones((prev) => prev.map((zone) => zone.id === zoneId ? updateZoneOccupancy(zone, zone.occupied + 1) : zone));

    appendLog({
      actor: currentUser.name,
      type: "Entry",
      target: session.id,
      message: `Entry approved for ${selectedZone.name}. Session created.`,
      result: "Success",
    });

    alert(`Entry approved. Session ID: ${session.id}`);
  };

  const handleMemberExit = () => {
    if (!currentUser || !selectedActiveSession) {
      alert("No active session found.");
      return;
    }

    const feeResult = calculateFee(selectedActiveSession, policies);
    let payment = null;
    if (feeResult.paymentRequired) {
      payment = createPaymentRequest({ sessionId: selectedActiveSession.id, amount: feeResult.amount });
      setPayments((prev) => [payment, ...prev]);
    }

    const closed = closeSession(selectedActiveSession, payment?.id || null);
    setSessions((prev) => prev.map((session) => session.id === selectedActiveSession.id ? closed : session));
    setZones((prev) => prev.map((zone) =>
      zone.id === selectedActiveSession.zoneId ? updateZoneOccupancy(zone, zone.occupied - 1) : zone
    ));

    appendLog({
      actor: currentUser.name,
      type: "Exit",
      target: selectedActiveSession.id,
      message: feeResult.paymentRequired
        ? `Exit processed. Mock BKPay payment ${payment.id} created for ${feeResult.amount.toLocaleString()} VND.`
        : "Exit processed without payment.",
      result: "Success",
    });

    alert(feeResult.paymentRequired
      ? `Exit processed. Payment request ${payment.id} is ${payment.status}.`
      : "Exit approved. No payment required."
    );
  };

  const handleCreateTemporaryTicket = (form) => {
    if (!form.visitorName?.trim() || !form.vehicleInfo?.trim()) {
      alert("Visitor name and vehicle information are required.");
      return;
    }

    const selectedZone = zones.find((zone) => zone.id === form.zoneId) || findBestZone(zones);
    if (!selectedZone || getAvailableSlots(selectedZone) <= 0 || selectedZone.gatewayStatus !== "online") {
      alert("No available zone for temporary access.");
      appendLog({
        actor: currentUser?.name || "Operator",
        type: "Temporary Access",
        target: form.vehicleInfo,
        message: "Temporary access rejected because no valid zone is available.",
        result: "Denied",
      });
      return;
    }

    const ticket = createTemporaryTicket(form);
    const session = createTemporarySession({ ticket, zoneId: selectedZone.id });

    setTickets((prev) => [ticket, ...prev]);
    setSessions((prev) => [session, ...prev]);
    setZones((prev) => prev.map((zone) => zone.id === selectedZone.id ? updateZoneOccupancy(zone, zone.occupied + 1) : zone));

    appendLog({
      actor: currentUser?.name || "Operator",
      type: "Temporary Access",
      target: ticket.id,
      message: `Temporary ticket issued for ${ticket.visitorName}.`,
      result: "Success",
    });

    alert(`Temporary ticket issued: ${ticket.id}`);
  };

  const handleTemporaryExit = (ticketId) => {
    const ticket = tickets.find((item) => item.id === ticketId);
    const activeSession = sessions.find((session) => session.userId === ticketId && session.status === "Active");

    if (!ticket || !activeSession) {
      alert("No active temporary session found for this ticket.");
      appendLog({
        actor: currentUser?.name || "Operator",
        type: "Temporary Exit",
        target: ticketId,
        message: "Temporary exit rejected because no active session exists.",
        result: "Denied",
      });
      return;
    }

    const feeResult = calculateFee(activeSession, policies);
    const payment = createPaymentRequest({ sessionId: activeSession.id, amount: feeResult.amount });
    const paidPayment = updatePaymentStatus(payment, "Paid");
    const closed = closeSession(activeSession, paidPayment.id);

    setPayments((prev) => [paidPayment, ...prev]);
    setTickets((prev) => prev.map((item) => item.id === ticketId ? { ...item, status: "Closed" } : item));
    setSessions((prev) => prev.map((session) => session.id === activeSession.id ? closed : session));
    setZones((prev) => prev.map((zone) =>
      zone.id === activeSession.zoneId ? updateZoneOccupancy(zone, zone.occupied - 1) : zone
    ));

    appendLog({
      actor: currentUser?.name || "Operator",
      type: "Temporary Exit",
      target: ticketId,
      message: `Temporary exit validated. Fee ${feeResult.amount.toLocaleString()} VND marked paid in mock BKPay.`,
      result: "Success",
    });

    alert(`Temporary exit completed. Payment ${paidPayment.id} marked Paid.`);
  };

  const handleResolveLostTicket = (ticketId) => {
    setTickets((prev) => prev.map((ticket) => ticket.id === ticketId ? { ...ticket, status: "Lost" } : ticket));
    appendLog({
      actor: currentUser?.name || "Operator",
      type: "Exception",
      target: ticketId,
      message: "Lost-ticket case resolved by authorized operator.",
      result: "Resolved",
    });
    alert("Lost-ticket exception has been recorded.");
  };

  const handleOccupy = (zoneId) => {
    setZones((prev) => prev.map((zone) => zone.id === zoneId ? updateZoneOccupancy(zone, zone.occupied + 1) : zone));
    appendLog({
      actor: currentUser?.name || "System",
      type: "IoT Update",
      target: zoneId,
      message: "Simulated sensor update: one slot occupied.",
      result: "Success",
    });
  };

  const handleRelease = (zoneId) => {
    setZones((prev) => prev.map((zone) => zone.id === zoneId ? updateZoneOccupancy(zone, zone.occupied - 1) : zone));
    appendLog({
      actor: currentUser?.name || "System",
      type: "IoT Update",
      target: zoneId,
      message: "Simulated sensor update: one slot released.",
      result: "Success",
    });
  };

  const handleToggleGateway = (zoneId) => {
    setZones((prevZones) => {
      const updated = prevZones.map((zone) => zone.id === zoneId ? toggleGateway(zone) : zone);
      const changed = updated.find((zone) => zone.id === zoneId);
      const alert = buildDeviceAlert(changed);

      if (alert) {
        setAlerts((prev) => [alert, ...prev]);
        appendLog({
          actor: currentUser?.name || "System",
          type: "Device Fault",
          target: zoneId,
          message: alert.message,
          result: "Warning",
        });
      } else {
        appendLog({
          actor: currentUser?.name || "System",
          type: "Device Recovery",
          target: zoneId,
          message: `${changed.name} gateway is online again.`,
          result: "Success",
        });
      }

      return updated;
    });
  };

  const handleUpdatePayment = (paymentId, status) => {
    setPayments((prev) => prev.map((payment) =>
      payment.id === paymentId ? updatePaymentStatus(payment, status) : payment
    ));
    appendLog({
      actor: currentUser?.name || "System",
      type: "Payment",
      target: paymentId,
      message: `Payment status changed to ${status}.`,
      result: status,
    });
  };

  const handleSavePolicy = (policy) => {
    setPolicies((prev) => {
      const withoutSameTypeActive = policy.active
        ? prev.map((item) => item.userType === policy.userType ? { ...item, active: false } : item)
        : prev;

      const exists = withoutSameTypeActive.some((item) => item.id === policy.id);
      return exists
        ? withoutSameTypeActive.map((item) => item.id === policy.id ? policy : item)
        : [policy, ...withoutSameTypeActive];
    });

    appendLog({
      actor: currentUser?.name || "Admin",
      type: "Policy",
      target: policy.id,
      message: `Pricing policy saved: ${policy.name}.`,
      result: "Success",
    });

    alert("Pricing policy saved.");
  };

  if (!currentUser) {
    return <LoginPage users={users} onLogin={handleLogin} />;
  }

  const pageProps = {
    currentUser,
    users,
    zones,
    sessions,
    tickets,
    payments,
    logs,
    policies,
    alerts,
    setActivePage,
    onMemberEntry: handleMemberEntry,
    onMemberExit: handleMemberExit,
    onCreateTemporaryTicket: handleCreateTemporaryTicket,
    onTemporaryExit: handleTemporaryExit,
    onResolveLostTicket: handleResolveLostTicket,
    onOccupy: handleOccupy,
    onRelease: handleRelease,
    onToggleGateway: handleToggleGateway,
    onUpdatePayment: handleUpdatePayment,
    onSavePolicy: handleSavePolicy,
  };

  const pages = {
    "user-dashboard": <UserDashboard {...pageProps} />,
    "availability": <ParkingAvailabilityMap {...pageProps} />,
    "entry-exit": <EntryExitPage {...pageProps} />,
    "temporary-access": <TemporaryAccessPage {...pageProps} />,
    "operator-dashboard": <OperatorDashboard {...pageProps} />,
    "sensor-simulation": <SensorSimulationPage {...pageProps} />,
    "admin-dashboard": <AdminDashboard {...pageProps} />,
    "pricing-policy": <PricingPolicyPage {...pageProps} />,
    "audit-log-report": <AuditLogReportPage {...pageProps} />,
  };

  return (
    <Layout
      currentUser={currentUser}
      activePage={activePage}
      setActivePage={setActivePage}
      onLogout={handleLogout}
    >
      {pages[activePage] || pages["user-dashboard"]}
    </Layout>
  );
}
